# Related Tutorials

* [Spring Boot Data Redis with Lettuce and Jedis](https://howtodoinjava.com/spring-data/spring-boot-redis-with-lettuce-jedis/)