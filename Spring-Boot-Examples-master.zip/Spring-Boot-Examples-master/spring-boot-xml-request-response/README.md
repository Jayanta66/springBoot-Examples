# Related Tutorials

1. [Spring Boot REST – Handling XML Request and Response](https://howtodoinjava.com/spring-boot/xml-request-response-body/)