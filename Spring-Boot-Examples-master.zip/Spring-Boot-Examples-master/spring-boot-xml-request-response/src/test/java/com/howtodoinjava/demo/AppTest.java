package com.howtodoinjava.demo;

import org.junit.jupiter.api.Test;

public class AppTest
{
    @Test
    void loadsContext(){
    }
}
