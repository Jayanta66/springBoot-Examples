# Related Tutorials

* [Spring Boot Actuator ‘/Info’ Endpoint](https://howtodoinjava.com/spring-boot/info-endpoint-custom-info/)