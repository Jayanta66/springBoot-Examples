# Related Tutorials

1. [Spring MVC Custom Validation Annotation](https://howtodoinjava.com/spring-mvc/spring-custom-constraint-annotation/)