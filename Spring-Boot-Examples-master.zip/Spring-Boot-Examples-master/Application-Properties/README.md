# Related Tutorials

* [How to Configure Properties with Spring
  Boot](https://howtodoinjava.com/spring-boot/properties-with-spring-boot/)