# Related Tutorials

1. [Load Initial Data with SQL Scripts in Spring Boot](https://howtodoinjava.com/spring-boot/execute-sql-scripts-on-startup/)
2. [Spring @Sql, @SqlGroup](https://howtodoinjava.com/spring/spring-sql-sqlgroup-and-sqlmergemode/)