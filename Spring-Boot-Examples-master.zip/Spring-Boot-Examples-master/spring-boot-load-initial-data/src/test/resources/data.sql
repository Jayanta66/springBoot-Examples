INSERT INTO ITEM (name) VALUES ('Mobiles');
INSERT INTO ITEM (name) VALUES ('Laptops');