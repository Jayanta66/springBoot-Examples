INSERT INTO ITEM (name) VALUES ('Tickets');
INSERT INTO ITEM (name) VALUES ('Spices');