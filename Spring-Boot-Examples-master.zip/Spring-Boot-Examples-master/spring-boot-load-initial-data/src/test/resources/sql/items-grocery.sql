INSERT INTO ITEM (name) VALUES ('Grocery-1');
INSERT INTO ITEM (name) VALUES ('Grocery-2');