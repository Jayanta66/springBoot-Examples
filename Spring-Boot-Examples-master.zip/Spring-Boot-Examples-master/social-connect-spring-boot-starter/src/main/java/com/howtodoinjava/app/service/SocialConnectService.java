package com.howtodoinjava.app.service;

import java.util.List;

public interface SocialConnectService {
  public List<String> fetchMessages();
}
