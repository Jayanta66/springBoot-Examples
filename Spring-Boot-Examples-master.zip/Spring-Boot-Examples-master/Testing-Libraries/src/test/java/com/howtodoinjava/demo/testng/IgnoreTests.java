package com.howtodoinjava.demo.testng;

import org.testng.annotations.Test;

@Test(enabled = false)
public class IgnoreTests {
  @Test
  public void testCase() {
  }
}
