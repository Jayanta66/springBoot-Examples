package com.howtodoinjava.app;

import org.junit.jupiter.api.Test;

class AppTests {

  @Test
  void contextLoads() {
  }

}