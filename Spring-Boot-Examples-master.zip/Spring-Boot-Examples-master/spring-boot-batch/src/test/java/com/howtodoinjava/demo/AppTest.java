package com.howtodoinjava.demo;

public class AppTest {
}
