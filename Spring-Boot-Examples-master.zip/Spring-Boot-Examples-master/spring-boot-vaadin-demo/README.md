# Related Tutorials

* [Spring Boot and Vaadin CRUD Example](https://howtodoinjava.com/vaadin/spring-boot-and-vaadin-crud-example/)