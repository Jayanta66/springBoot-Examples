package com.howtodoinjava.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRestApiApplicationTests {

  @Test
  void contextLoads() {
  }

}
