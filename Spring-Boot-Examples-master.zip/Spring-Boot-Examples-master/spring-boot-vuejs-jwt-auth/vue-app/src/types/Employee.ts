interface Employee {
  id: number;
  name: string;
  phone: string;
  email: string;
  position: string;
  bio: string;
}
export default Employee;
