<template>
  <footer>
    <div class="container">
      <p>&copy; 2023 Hamza . All rights reserved.</p>
    </div>
  </footer>
</template>

<script>
export default {
  name: "FooterComponent",
};
</script>

<style scoped>
footer {
  background-color: #f8f8f8;
  padding: 20px;
  text-align: center;
  height: 10px;
}
</style>
