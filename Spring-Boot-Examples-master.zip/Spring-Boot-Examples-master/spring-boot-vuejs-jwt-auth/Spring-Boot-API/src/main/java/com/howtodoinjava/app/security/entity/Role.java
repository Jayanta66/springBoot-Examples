package com.howtodoinjava.app.security.entity;

public enum Role {
    ADMIN,USER
}
